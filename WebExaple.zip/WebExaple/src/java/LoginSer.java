/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

/**
 *
 * @author Hp
 */
public class LoginSer extends HttpServlet {


  
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       PrintWriter out = response.getWriter();
        try
        {
          Class.forName("com.mysql.jdbc.Driver");
          Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance","root","");
          Statement st = conn.createStatement();
          ResultSet x = st.executeQuery("select * from reg where staffid='"+request.getParameter("txtstaffid")+"' and password='"+request.getParameter("txtpass")+"'");
          if(x.next())
          {
              HttpSession session = request.getSession();
              session.setAttribute("sessname",x.getString(3));
             response.sendRedirect("dashboard.jsp");
          }
          else
          {
               response.sendRedirect("login.jsp?q=login not successfully");
          }
        }
        catch(Exception ex)
        {
          out.print(ex.getMessage().toString());  
        }
    }

   

}
